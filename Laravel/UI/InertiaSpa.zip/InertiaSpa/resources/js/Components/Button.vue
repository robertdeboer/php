<template>
    <button>{{ message }}</button>
</template>
<script setup>
defineProps({
  message: {
    required: true,
    type: String
  }
})
</script>