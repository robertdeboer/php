<script setup>
    import Layout from "../../Layouts/Layout.vue";
    import { Head } from '@inertiajs/vue3'
</script>
<template>
    <Layout>
        <Head title="Dashboard" />
        Welcome to the dashboard
    </Layout>
</template>