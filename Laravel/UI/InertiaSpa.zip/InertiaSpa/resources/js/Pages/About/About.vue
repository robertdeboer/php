<script setup>
import Layout from "../../Layouts/Layout.vue";
import { Head } from '@inertiajs/vue3'
import Button from '../../Components/Button.vue'
</script>
<template>
    <Layout>
        <Head title="About Us" />
        About Us
        <Button message="Yo"/>
    </Layout>
</template>