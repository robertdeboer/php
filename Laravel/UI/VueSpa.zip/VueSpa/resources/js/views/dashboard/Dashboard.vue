<template>
    <div class="px-5 py-5">
        <h1 class="text-3xl mb-3">Dashboard Page </h1>
        <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iure nihil nam labore deleniti ratione eius
            consectetur vel illo nemo reiciendis ullam, incidunt quam doloribus praesentium id, corrupti rem. Ullam
            dolores, non voluptate quis maxime ducimus temporibus repudiandae nihil quasi? Similique, accusamus eos sunt
            fugit tempora sit necessitatibus vero placeat corrupti voluptatem pariatur aliquid debitis corporis iusto.
            Suscipit, sunt! Reprehenderit aut at magnam, corrupti sunt eos! Laboriosam, optio! Reprehenderit atque nisi
            consectetur assumenda porro, magnam soluta molestias! Quisquam possimus impedit nemo deserunt, neque
            explicabo recusandae doloremque. Deleniti voluptatem officia fugiat praesentium labore. Laudantium facere
            sapiente modi magnam incidunt, qui, excepturi ipsam eum at repudiandae perspiciatis fuga necessitatibus,
            temporibus tempore ea laborum expedita dolore. Beatae optio tenetur asperiores id aliquid delectus maiores
            consequatur nostrum cum consequuntur necessitatibus velit aspernatur sit natus, vel fugit libero? Aliquam,
            dignissimos tenetur pariatur beatae et nihil optio quae possimus officiis voluptatum, at odio soluta.
            Reiciendis reprehenderit doloribus eum amet ut libero laborum, ullam assumenda, mollitia sunt numquam
            pariatur commodi voluptatibus asperiores hic quis veniam alias corporis nulla corrupti odio officia atque.
            Quas architecto ad aut minus fuga obcaecati corporis accusantium iure eligendi. Accusantium atque, nulla
            laborum ab temporibus mollitia aliquid iste accusamus repudiandae provident necessitatibus voluptates, unde
            fuga voluptate illum vel officia omnis. Laboriosam numquam quasi voluptatum rerum placeat eveniet sint,
            maxime, amet veritatis nobis quaerat consequuntur ullam! Eaque, vitae dolorem alias veniam tempore mollitia
            doloribus laudantium maiores omnis, necessitatibus commodi! Similique dolore maxime cum corporis esse eos,
            corrupti tempore velit maiores quos officia laborum? Ipsa, quidem!
        </p>
    </div>
</template>

<script setup>


</script>