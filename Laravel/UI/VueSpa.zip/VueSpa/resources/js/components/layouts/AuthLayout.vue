<template>
    <section class="flex flex-col h-screen">
        <nav class="w-full py-4 bg-blue-600 px-3 min-h-[10%] flex justify-center">
            <img src="../../assets/coffeeLogo.png" alt="coffeeLogo" class="h-11">
        </nav>
        <router-view/>
        <footer class="w-full py-3 bg-blue-800 text-center text-white min-h-[5%]">
            Copyright Forever
        </footer>
    </section>
</template>


