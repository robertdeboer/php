<template>
    <svg
        width="700pt"
        height="700pt"
        version="1.1"
        viewBox="0 0 700 700"
        xmlns="http://www.w3.org/2000/svg"
    >
        <g>
            <path
                d="m333.67 135.33h37.332l-46.668 46.668h-81.664l-60.668 74.668 28 21 49-60.668h81.668l56-56v39.668h35v-100.34h-98z"
            />
            <path d="m289.33 268.33h53.668v172.67h-53.668z" />
            <path d="m205.33 329h53.668v114.33h-53.668z" />
            <path d="m371 226.33h53.668v214.67h-53.668z" />
            <path d="m450.33 140h53.668v301h-53.668z" />
        </g>
    </svg>
</template>
